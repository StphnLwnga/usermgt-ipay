<?php

namespace Vanguard\Events\User;

use Vanguard\User;

class RequestedPasswordResetEmail
{
    /**
     * @var User
     */
    private $user;

    public function __construct(User $user)
    {
        $this->user = $user;
    }

    /**
     * @return User
     */
    public function getUser()
    {
        return $this->user;
    }
}
