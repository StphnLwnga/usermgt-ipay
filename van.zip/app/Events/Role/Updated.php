<?php

namespace Vanguard\Events\Role;

class Updated extends RoleEvent {}